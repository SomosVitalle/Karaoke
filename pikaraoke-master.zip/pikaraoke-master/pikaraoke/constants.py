LANGUAGES = {
    "en": "English",
    "es_VE": "Spanish (Venezuela)",
    "fi_FI": "Finnish",
    "zh_CN": "Chinese",
    "pt_BR": "Brazilian Portuguese",
    "it_IT": "Italian",
}
